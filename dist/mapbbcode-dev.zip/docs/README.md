# Map BBCode

This JavaScript module allows easy integration of [map] bbcode into forums and other collaboration tools.

*documentation todo*
